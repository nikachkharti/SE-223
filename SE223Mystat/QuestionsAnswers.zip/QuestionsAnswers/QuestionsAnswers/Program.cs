﻿namespace QuestionsAnswers
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] questionsTextArray = File.ReadAllLines(@"../../../Tests.txt");

            List<Question> Questions = new();

            foreach (string item in questionsTextArray)
            {
                Questions.Add(Question.Parse(item));
            }


            foreach (var question in Questions)
            {
                Console.WriteLine(question.QuestionText);
                foreach (var answer in question.Answers)
                {
                    Console.WriteLine(answer);
                }
                Console.WriteLine("------------------------------------------------");
            }

        }
    }
}
