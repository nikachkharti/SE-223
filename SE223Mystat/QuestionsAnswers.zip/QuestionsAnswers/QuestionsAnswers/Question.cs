﻿namespace QuestionsAnswers
{
    public class Question
    {
        public string QuestionText { get; set; }
        public List<string> Answers { get; set; } = new();
        private static string CorrectAnswer { get; set; }

        public static Question Parse(string question)
        {
            Question result = new();

            try
            {
                string[] splitedQuestion = question.Split('|');

                if (splitedQuestion.Length != 5)
                    throw new FormatException();

                result.QuestionText = splitedQuestion[0];
                result.Answers.Add(splitedQuestion[1]);
                result.Answers.Add(splitedQuestion[2]);
                result.Answers.Add(splitedQuestion[3]);
                result.Answers.Add(splitedQuestion[4]);

                CorrectAnswer = GetCorrectAnswer(result.Answers);
                RemoveAsterix(result.Answers);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return result;
        }


        private static void RemoveAsterix(List<string> answers)
        {
            for (int i = 0; i < answers.Count; i++)
                answers[i] = answers[i].TrimEnd('*');
        }

        private static string GetCorrectAnswer(List<string> answers)
        {
            string result = string.Empty;
            foreach (string answer in answers)
            {
                if (answer.EndsWith('*'))
                    result = answer;
            }
            return result;
        }

        public static bool IsAnswerCorrect(string answer)
        {
            return answer == CorrectAnswer;
        }

    }
}
